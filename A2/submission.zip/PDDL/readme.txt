Name: Manny Cassar
Student Number: 20213773
NetID: 19mmc4

I worked on this project alone and thus have contributed everything!