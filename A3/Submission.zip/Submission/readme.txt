Hello TA!

Group member(s): Manny Cassar (19mmc4 | 20213773)

Group #:

I decided to attempt this assignment myself and it was challenging but very rewarding!
All the work below YOURCODEHERE lines was expressly written by myself. I used comments to explain my way through while writing the code and polished them up to make sense to the reader.

Thanks,
Manny